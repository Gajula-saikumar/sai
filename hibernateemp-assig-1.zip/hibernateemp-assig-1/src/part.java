import java.util.*;

import org.hibernate.*;
import org.hibernate.cfg.*;

public class part
{
	public static void main(String args[])throws Exception
	{
		Configuration cfg=new Configuration();
		SessionFactory sf=cfg.configure().buildSessionFactory();
		Session ss=sf.openSession();
		mypojo pojo=new mypojo();
		
		String empno, name, phoneno, address;
		Scanner sc = new Scanner(System.in);
		while (true) {
			System.out.println("Select 1 for Inserting");
			System.out.println("Select 2 for Deleting");
			System.out.println("Select 3 for Updating");
			System.out.println("Select 4 for Display");
			System.out.println("Select 5 for Exit");
			int x = sc.nextInt();
			switch (x) {
			case 1:
				Transaction tx = ss.beginTransaction();
				Query q = ss.createQuery("from mypojo"); // query select from mypojo class(table)

				System.out.println("INSERTING VALUES");
				System.out.println("Enter empno");
				empno = sc.next();
				pojo.setEmpno(empno);
				System.out.println("Enter name");
				name = sc.next();
				pojo.setName(name);
				System.out.println("Enter phoneno");
				phoneno = sc.next();
				pojo.setPhoneno(phoneno);
				System.out.println("Enter address");
				address = sc.next();
				pojo.setAddress(address);
				ss.save(pojo);

				q.setFirstResult(0);
				q.setMaxResults(10);
				List list = q.list();// will return the records from 0 to 10th number
				System.out.println(list);
				tx.commit();
				break;
			case 2:
				Transaction tx1 = ss.beginTransaction();
				System.out.println("Deleting data");
				System.out.println("Enter empoyee id for deleteing ");
				empno = sc.next();
				Query q3 = ss.createQuery("delete from mypojo where empno=:x");
				q3.setParameter("x", empno);
				q3.executeUpdate();
				System.out.println(empno + " row Deleted");
				tx1.commit();
				break;
			case 3:
				Transaction tx2 = ss.beginTransaction();
				System.out.println("Updating row ");
				System.out.println("Enter emp no for update");
				empno = sc.next();
				System.out.println("Enter name");
				name = sc.next();
				System.out.println("Enter phone no");
				phoneno = sc.next();
				System.out.println("Enter address");
				address = sc.next();

				Query q4 = ss.createQuery("update mypojo set name=:n, phoneno=:p, address=:ad where empno=:e");
				q4.setParameter("n", name);
				q4.setParameter("p", phoneno);
				q4.setParameter("ad", address);
				q4.setParameter("e", empno);

				int status1 = q4.executeUpdate();
				System.out.println(empno + "row updated " + status1);
				tx2.commit();
				break;
			case 4:

				Query q5 = ss.createQuery("from mypojo");
				q5.setFirstResult(0);
				q5.setMaxResults(10);
				List stud1 = q5.list();
				System.out.println(stud1);
				Iterator it1 = stud1.iterator();
				while (it1.hasNext()) {
					pojo = (mypojo) it1.next();
					System.out.println("Display Last Entry");
					System.out.println(pojo.getEmpno());
					System.out.println(pojo.getName());
					System.out.println(pojo.getPhoneno());
					System.out.println(pojo.getAddress());
				}
				break;
			case 5:
				System.exit(x);
				break;

			}

		}}}
		 
		/*Transaction tx=ss.beginTransaction();
		Query q=ss.createQuery("from mypojo");
		
		q.setFirstResult(0);  
		q.setMaxResults(10);  
		List list=q.list();//will return the records from 0 to 10th number
		System.out.println(list);
		
		List stud=q.list();
		Iterator it=stud.iterator();
		while(it.hasNext())
		{
			pojo=(mypojo)it.next();
			System.out.println(pojo.getEmpno());
			System.out.println(pojo.getName());
			System.out.println(pojo.getPhoneno());
			System.out.println(pojo.getAddress());
		}*/
		
		
		/*
		 * Query q1=ss.createQuery("from mypojo1"); List stud1=q1.list(); Iterator
		 * it1=stud1.iterator(); while(it1.hasNext()) { pojo1=(mypojo)it1.next();
		 * System.out.println(pojo1.getPhoneno()); System.out.println(pojo1.getEmail());
		 * System.out.println(pojo1.getPassword()); }
		 */
	/*	 
		Query q2=ss.createQuery("update mypojo set name=:n where empno=:i"); 
		//we use pojo class name not the table name
		q2.setParameter("n","kamal hassan");  
		q2.setParameter("i","101");  
		  
		int status=q2.executeUpdate();  
		System.out.println(status);  
		
		
		Query q3=ss.createQuery("delete from mypojo where empno='103' ");  
		//specifying class name (mypojo) not tablename  
		int status1=q3.executeUpdate();
		System.out.println(status1);  
		tx.commit();  
		
		Query q4=ss.createQuery("select count(empno) from mypojo");  
		System.out.println(q4);
		
	}*/




/*
 * create table details1(phoneno varchar2(30),email varchar2(30),password
 * varchar2(30));
 * 
 * insert into details1 values('99887766','sandip@gmail.com','1234')
 * 
 * create table details(rollno varchar2(30),name varchar2(30),address
 * varchar2(30));
 * 
 * insert into details values('101','sandip','bangalore')
 */