public class Emp {
private int id,age,department,salary;
private String name,password,email,country;
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getPassword() {
	return password;
}
public void setPassword(String password) {
	this.password = password;
}
public String getEmail() {
	return email;
}
public void setEmail(String email) {
	this.email = email;
}
public String getCountry() {
	return country;
}
public void setCountry(String country) {
	this.country = country;
}
public int getage() {
	return age;
}
public void setage(int age) {
	this.age = age;
}
public int getdepartment() {
	return department;
}
public void setdepartment(int department) {
	this.department = department;
}
public int getsalary() {
	return salary;
}
public void setsalary(int salary) {
	this.salary = salary;
}

}
